import boto3

s3 = boto3.client("s3")
BUCKET = "event-driven-data-bucket-demo"

def lambda_handler(event, context):
    response = s3.list_objects_v2(
        Bucket=BUCKET,
        Prefix="raw-data/"
    )

    count = response.get("KeyCount", 0)
    print(f"Daily Report: {count} events processed")

    return {"events": count}
