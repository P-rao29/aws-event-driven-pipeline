import json
import boto3
import datetime

s3 = boto3.client("s3")
BUCKET = "event-driven-data-bucket-demo"

def lambda_handler(event, context):
    timestamp = datetime.datetime.utcnow().isoformat()
    key = f"raw-data/{timestamp}.json"

    s3.put_object(
        Bucket=BUCKET,
        Key=key,
        Body=json.dumps(event)
    )

    return {"status": "stored"}
