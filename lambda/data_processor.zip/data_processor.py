import json
import boto3
import datetime
import os

s3 = boto3.client("s3")
BUCKET = os.environ.get("BUCKET_NAME")

def lambda_handler(event, context):
    timestamp = datetime.datetime.utcnow().isoformat()
    key = f"raw-data/{timestamp}.json"

    data = event.get("detail", event)

    s3.put_object(
        Bucket=BUCKET,
        Key=key,
        Body=json.dumps({
            "timestamp": timestamp,
            "data": data
        })
    )

    return {"status": "stored"}
